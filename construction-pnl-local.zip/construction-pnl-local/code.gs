/**
 * 현장별 매출·손익 관리 시스템 - 로컬 실행 서버
 *
 * 실행 방법:
 *   node code.gs
 *   또는
 *   node code.js
 *
 * 그 후 브라우저에서 http://localhost:3000 접속
 *
 * 데이터는 ./data/db.json 파일에 자동 저장됩니다.
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');
const crypto = require('crypto');

// ============================================================
// 설정
// ============================================================
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');
const INDEX_FILE = path.join(__dirname, 'index.html');

// ============================================================
// 데이터베이스 (JSON 파일 기반)
// ============================================================
const DEFAULT_DB = {
  projects: [],
  monthly: [],
  forecasts: [],
  users: [],
  audit: []
};

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, JSON.stringify(DEFAULT_DB, null, 2), 'utf8');
  }
}

function loadDB() {
  ensureDataDir();
  try {
    const raw = fs.readFileSync(DB_FILE, 'utf8');
    return JSON.parse(raw);
  } catch (err) {
    console.error('DB 로드 실패, 기본값 사용:', err.message);
    return JSON.parse(JSON.stringify(DEFAULT_DB));
  }
}

function saveDB(db) {
  ensureDataDir();
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf8');
}

let DB = loadDB();

function commit() {
  saveDB(DB);
}

// ============================================================
// 유틸리티
// ============================================================
function uuid() {
  return crypto.randomUUID();
}

function toNumber(v) {
  if (v === null || v === undefined || v === '') return 0;
  if (typeof v === 'number') return v;
  const n = Number(String(v).replace(/,/g, ''));
  return isNaN(n) ? 0 : n;
}

function normalizeYearMonth(ym) {
  if (!ym) return '';
  const s = String(ym).trim();
  // YYYY-MM, YYYY/MM, YYYY.MM, YYYYMM 모두 지원
  const m = s.match(/^(\d{4})[-./]?(\d{1,2})$/);
  if (!m) return s;
  const year = m[1];
  const month = String(parseInt(m[2], 10)).padStart(2, '0');
  return `${year}-${month}`;
}

function getYearOf(ym) {
  return normalizeYearMonth(ym).slice(0, 4);
}

function currentYearMonth() {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  return `${y}-${m}`;
}

function safeDiv(a, b) {
  return b === 0 ? 0 : a / b;
}

function ratio(a, b) {
  return safeDiv(a, b) * 100;
}

function round(n, dp = 2) {
  const f = Math.pow(10, dp);
  return Math.round(n * f) / f;
}

function audit(action, entity, detail) {
  DB.audit.push({
    id: uuid(),
    timestamp: new Date().toISOString(),
    action,
    entity,
    detail: typeof detail === 'string' ? detail : JSON.stringify(detail)
  });
  // audit 로그가 너무 커지지 않게 최근 1000개만 유지
  if (DB.audit.length > 1000) {
    DB.audit = DB.audit.slice(-1000);
  }
}

// ============================================================
// 검증 (Validator)
// ============================================================
function validateProject(p) {
  const errors = [];
  if (!p.name || !p.name.trim()) errors.push('현장명은 필수입니다.');
  if (toNumber(p.contractAmount) < 0) errors.push('수주금액은 0 이상이어야 합니다.');
  if (toNumber(p.annualPlanAmount) < 0) errors.push('연간계획은 0 이상이어야 합니다.');
  return errors;
}

function validateMonthly(m, existingId) {
  const errors = [];
  if (!m.projectId) errors.push('현장이 지정되지 않았습니다.');
  if (!normalizeYearMonth(m.yearMonth)) errors.push('년월 형식이 잘못되었습니다.');
  const revenue = toNumber(m.revenue);
  const cost = toNumber(m.cost);
  if (revenue < 0) errors.push('매출은 0 이상이어야 합니다.');
  if (cost < 0) errors.push('매출원가는 0 이상이어야 합니다.');
  if (revenue === 0 && cost > 0) {
    errors.push('매출이 0일 때는 매출원가도 0이어야 합니다.');
  }
  // 중복 검사
  const ym = normalizeYearMonth(m.yearMonth);
  const dup = DB.monthly.find(
    (x) => x.projectId === m.projectId && x.yearMonth === ym && x.id !== existingId
  );
  if (dup) errors.push(`이미 ${ym} 월 데이터가 존재합니다.`);
  return errors;
}

function validateForecast(f) {
  const errors = [];
  if (!f.projectId) errors.push('현장이 지정되지 않았습니다.');
  if (toNumber(f.estimatedRevenue) < 0) errors.push('추정 매출은 0 이상이어야 합니다.');
  if (toNumber(f.estimatedCost) < 0) errors.push('추정 매출원가는 0 이상이어야 합니다.');
  return errors;
}

// ============================================================
// Project 서비스
// ============================================================
const ProjectService = {
  list() {
    return DB.projects.map(this._serialize);
  },
  get(id) {
    const p = DB.projects.find((x) => x.id === id);
    return p ? this._serialize(p) : null;
  },
  create(data) {
    const errors = validateProject(data);
    if (errors.length) throw new Error(errors.join(' / '));
    const p = {
      id: uuid(),
      name: data.name.trim(),
      client: data.client || '',
      contractAmount: toNumber(data.contractAmount),
      startDate: data.startDate || '',
      endDate: data.endDate || '',
      annualPlanAmount: toNumber(data.annualPlanAmount),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    DB.projects.push(p);
    audit('CREATE', 'project', { id: p.id, name: p.name });
    commit();
    return this._serialize(p);
  },
  update(id, data) {
    const errors = validateProject(data);
    if (errors.length) throw new Error(errors.join(' / '));
    const idx = DB.projects.findIndex((x) => x.id === id);
    if (idx === -1) throw new Error('현장을 찾을 수 없습니다.');
    const p = DB.projects[idx];
    p.name = data.name.trim();
    p.client = data.client || '';
    p.contractAmount = toNumber(data.contractAmount);
    p.startDate = data.startDate || '';
    p.endDate = data.endDate || '';
    p.annualPlanAmount = toNumber(data.annualPlanAmount);
    p.updatedAt = new Date().toISOString();
    audit('UPDATE', 'project', { id, name: p.name });
    commit();
    return this._serialize(p);
  },
  remove(id) {
    const idx = DB.projects.findIndex((x) => x.id === id);
    if (idx === -1) throw new Error('현장을 찾을 수 없습니다.');
    const p = DB.projects[idx];
    DB.projects.splice(idx, 1);
    // Cascade 삭제
    DB.monthly = DB.monthly.filter((x) => x.projectId !== id);
    DB.forecasts = DB.forecasts.filter((x) => x.projectId !== id);
    audit('DELETE', 'project', { id, name: p.name });
    commit();
    return { ok: true };
  },
  _serialize(p) {
    return { ...p };
  }
};

// ============================================================
// Monthly 서비스
// ============================================================
const MonthlyService = {
  listByProject(projectId) {
    return DB.monthly
      .filter((x) => x.projectId === projectId)
      .map(this._serialize)
      .sort((a, b) => a.yearMonth.localeCompare(b.yearMonth));
  },
  listAll() {
    return DB.monthly.map(this._serialize);
  },
  listByYear(year) {
    return DB.monthly
      .filter((x) => getYearOf(x.yearMonth) === String(year))
      .map(this._serialize);
  },
  create(data) {
    const errors = validateMonthly(data);
    if (errors.length) throw new Error(errors.join(' / '));
    const m = {
      id: uuid(),
      projectId: data.projectId,
      yearMonth: normalizeYearMonth(data.yearMonth),
      revenue: toNumber(data.revenue),
      cost: toNumber(data.cost),
      memo: data.memo || '',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    DB.monthly.push(m);
    audit('CREATE', 'monthly', { projectId: m.projectId, yearMonth: m.yearMonth });
    commit();
    return this._serialize(m);
  },
  update(id, data) {
    const errors = validateMonthly(data, id);
    if (errors.length) throw new Error(errors.join(' / '));
    const idx = DB.monthly.findIndex((x) => x.id === id);
    if (idx === -1) throw new Error('월별 데이터를 찾을 수 없습니다.');
    const m = DB.monthly[idx];
    m.yearMonth = normalizeYearMonth(data.yearMonth);
    m.revenue = toNumber(data.revenue);
    m.cost = toNumber(data.cost);
    m.memo = data.memo || '';
    m.updatedAt = new Date().toISOString();
    audit('UPDATE', 'monthly', { id });
    commit();
    return this._serialize(m);
  },
  remove(id) {
    const idx = DB.monthly.findIndex((x) => x.id === id);
    if (idx === -1) throw new Error('월별 데이터를 찾을 수 없습니다.');
    DB.monthly.splice(idx, 1);
    audit('DELETE', 'monthly', { id });
    commit();
    return { ok: true };
  },
  bulkUpsert(items) {
    let inserted = 0;
    let updated = 0;
    const errors = [];
    items.forEach((item, i) => {
      try {
        const ym = normalizeYearMonth(item.yearMonth);
        const existing = DB.monthly.find(
          (x) => x.projectId === item.projectId && x.yearMonth === ym
        );
        if (existing) {
          this.update(existing.id, item);
          updated++;
        } else {
          this.create(item);
          inserted++;
        }
      } catch (err) {
        errors.push(`행 ${i + 1}: ${err.message}`);
      }
    });
    return { inserted, updated, errors };
  },
  _serialize(m) {
    const profit = m.revenue - m.cost;
    const costRatio = ratio(m.cost, m.revenue);
    return {
      ...m,
      profit,
      costRatio: round(costRatio, 2)
    };
  }
};

// ============================================================
// Forecast 서비스
// ============================================================
const ForecastService = {
  getByProject(projectId) {
    const f = DB.forecasts.find((x) => x.projectId === projectId);
    return f ? this._serialize(f) : null;
  },
  upsert(data) {
    const errors = validateForecast(data);
    if (errors.length) throw new Error(errors.join(' / '));
    const existing = DB.forecasts.find((x) => x.projectId === data.projectId);
    if (existing) {
      existing.estimatedRevenue = toNumber(data.estimatedRevenue);
      existing.estimatedCost = toNumber(data.estimatedCost);
      existing.memo = data.memo || '';
      existing.updatedAt = new Date().toISOString();
      audit('UPDATE', 'forecast', { projectId: data.projectId });
      commit();
      return this._serialize(existing);
    } else {
      const f = {
        id: uuid(),
        projectId: data.projectId,
        estimatedRevenue: toNumber(data.estimatedRevenue),
        estimatedCost: toNumber(data.estimatedCost),
        memo: data.memo || '',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      DB.forecasts.push(f);
      audit('CREATE', 'forecast', { projectId: f.projectId });
      commit();
      return this._serialize(f);
    }
  },
  _serialize(f) {
    const estimatedProfit = f.estimatedRevenue - f.estimatedCost;
    const estimatedCostRatio = ratio(f.estimatedCost, f.estimatedRevenue);
    return {
      ...f,
      estimatedProfit,
      estimatedCostRatio: round(estimatedCostRatio, 2)
    };
  }
};

// ============================================================
// Analytics 서비스 (핵심 로직)
// ============================================================
const AnalyticsService = {
  getDashboardSummary(yearMonth) {
    const ym = normalizeYearMonth(yearMonth) || currentYearMonth();
    const year = getYearOf(ym);
    const projects = ProjectService.list();

    // 전체 누계 (해당 연도)
    const yearlyMonthly = DB.monthly.filter((x) => getYearOf(x.yearMonth) === year);
    const ytdMonthly = yearlyMonthly.filter((x) => x.yearMonth <= ym);

    const totalContractAmount = projects.reduce((s, p) => s + p.contractAmount, 0);
    const totalAnnualPlan = projects.reduce((s, p) => s + p.annualPlanAmount, 0);

    const ytdRevenue = ytdMonthly.reduce((s, x) => s + x.revenue, 0);
    const ytdCost = ytdMonthly.reduce((s, x) => s + x.cost, 0);
    const ytdProfit = ytdRevenue - ytdCost;
    const ytdCostRatio = round(ratio(ytdCost, ytdRevenue), 2);
    const remaining = totalAnnualPlan - ytdRevenue;
    const achievementRate = round(ratio(ytdRevenue, totalAnnualPlan), 2);

    // 당월
    const currentMonth = yearlyMonthly.filter((x) => x.yearMonth === ym);
    const currentRevenue = currentMonth.reduce((s, x) => s + x.revenue, 0);
    const currentCost = currentMonth.reduce((s, x) => s + x.cost, 0);
    const currentProfit = currentRevenue - currentCost;
    const currentCostRatio = round(ratio(currentCost, currentRevenue), 2);

    // 현장별 요약
    const projectSummary = projects.map((p) => {
      const pYtd = ytdMonthly.filter((x) => x.projectId === p.id);
      const rev = pYtd.reduce((s, x) => s + x.revenue, 0);
      const cost = pYtd.reduce((s, x) => s + x.cost, 0);
      return {
        ...p,
        ytdRevenue: rev,
        ytdCost: cost,
        ytdProfit: rev - cost,
        ytdCostRatio: round(ratio(cost, rev), 2),
        achievementRate: round(ratio(rev, p.annualPlanAmount), 2)
      };
    });

    return {
      yearMonth: ym,
      year,
      totalContractAmount,
      totalAnnualPlan,
      ytdRevenue,
      ytdCost,
      ytdProfit,
      ytdCostRatio,
      remaining,
      achievementRate,
      currentRevenue,
      currentCost,
      currentProfit,
      currentCostRatio,
      projectCount: projects.length,
      projectSummary
    };
  },

  getProjectAnalysis(projectId, yearMonth) {
    const ym = normalizeYearMonth(yearMonth) || currentYearMonth();
    const year = getYearOf(ym);
    const project = ProjectService.get(projectId);
    if (!project) throw new Error('현장을 찾을 수 없습니다.');

    const allMonthly = MonthlyService.listByProject(projectId);
    const yearMonthly = allMonthly.filter((x) => getYearOf(x.yearMonth) === year);
    const ytdMonthly = yearMonthly.filter((x) => x.yearMonth <= ym);
    const currentMonth = yearMonthly.find((x) => x.yearMonth === ym) || {
      revenue: 0,
      cost: 0,
      profit: 0,
      costRatio: 0
    };

    const ytdRevenue = ytdMonthly.reduce((s, x) => s + x.revenue, 0);
    const ytdCost = ytdMonthly.reduce((s, x) => s + x.cost, 0);
    const ytdProfit = ytdRevenue - ytdCost;
    const ytdCostRatio = round(ratio(ytdCost, ytdRevenue), 2);
    const remaining = project.annualPlanAmount - ytdRevenue;
    const achievementRate = round(ratio(ytdRevenue, project.annualPlanAmount), 2);

    const forecast = ForecastService.getByProject(projectId);

    // 12개월 그리드
    const monthGrid = [];
    for (let i = 1; i <= 12; i++) {
      const mm = String(i).padStart(2, '0');
      const targetYm = `${year}-${mm}`;
      const m = yearMonthly.find((x) => x.yearMonth === targetYm);
      monthGrid.push({
        yearMonth: targetYm,
        revenue: m ? m.revenue : 0,
        cost: m ? m.cost : 0,
        profit: m ? m.profit : 0,
        costRatio: m ? m.costRatio : 0,
        id: m ? m.id : null
      });
    }

    // 계획 대비 분석
    const planAnalysis = {
      annualPlan: project.annualPlanAmount,
      ytdActual: ytdRevenue,
      gap: project.annualPlanAmount - ytdRevenue,
      achievementRate,
      forecastRevenue: forecast ? forecast.estimatedRevenue : 0,
      forecastProfit: forecast ? forecast.estimatedProfit : 0,
      planVsForecastGap: forecast
        ? forecast.estimatedRevenue - project.annualPlanAmount
        : 0
    };

    return {
      project,
      yearMonth: ym,
      year,
      currentMonth,
      ytd: {
        revenue: ytdRevenue,
        cost: ytdCost,
        profit: ytdProfit,
        costRatio: ytdCostRatio,
        remaining,
        achievementRate
      },
      planAnalysis,
      forecast,
      monthGrid,
      allMonthly: yearMonthly
    };
  },

  getMonthlyTrend(year) {
    const y = String(year || new Date().getFullYear());
    const yearMonthly = DB.monthly.filter((x) => getYearOf(x.yearMonth) === y);
    const trend = [];
    for (let i = 1; i <= 12; i++) {
      const mm = String(i).padStart(2, '0');
      const targetYm = `${y}-${mm}`;
      const monthData = yearMonthly.filter((x) => x.yearMonth === targetYm);
      const revenue = monthData.reduce((s, x) => s + x.revenue, 0);
      const cost = monthData.reduce((s, x) => s + x.cost, 0);
      trend.push({
        yearMonth: targetYm,
        month: i,
        revenue,
        cost,
        profit: revenue - cost,
        costRatio: round(ratio(cost, revenue), 2)
      });
    }
    return trend;
  },

  getProjectComparison(yearMonth) {
    const ym = normalizeYearMonth(yearMonth) || currentYearMonth();
    const year = getYearOf(ym);
    const projects = ProjectService.list();
    return projects.map((p) => {
      const ytd = DB.monthly.filter(
        (x) =>
          x.projectId === p.id &&
          getYearOf(x.yearMonth) === year &&
          x.yearMonth <= ym
      );
      const rev = ytd.reduce((s, x) => s + x.revenue, 0);
      const cost = ytd.reduce((s, x) => s + x.cost, 0);
      const forecast = ForecastService.getByProject(p.id);
      return {
        projectId: p.id,
        name: p.name,
        annualPlan: p.annualPlanAmount,
        ytdRevenue: rev,
        ytdCost: cost,
        ytdProfit: rev - cost,
        achievementRate: round(ratio(rev, p.annualPlanAmount), 2),
        forecastRevenue: forecast ? forecast.estimatedRevenue : 0,
        forecastProfit: forecast ? forecast.estimatedProfit : 0
      };
    });
  }
};

// ============================================================
// 샘플 데이터 시드
// ============================================================
function seedSampleData() {
  if (DB.projects.length > 0) {
    return { skipped: true, message: '이미 데이터가 있어 시드를 건너뜁니다.' };
  }
  const samples = [
    { name: '강남 오피스 빌딩', client: 'A건설', contractAmount: 50000000000, annualPlanAmount: 20000000000, startDate: '2026-01-01', endDate: '2027-12-31' },
    { name: '판교 R&D 센터', client: 'B기업', contractAmount: 35000000000, annualPlanAmount: 15000000000, startDate: '2026-03-01', endDate: '2027-06-30' },
    { name: '인천 물류창고', client: 'C로지스', contractAmount: 18000000000, annualPlanAmount: 12000000000, startDate: '2026-02-01', endDate: '2026-12-31' }
  ];
  const created = samples.map((s) => ProjectService.create(s));

  // 월별 샘플 (2026년 1~4월)
  const monthlySeeds = [
    { i: 0, ym: '2026-01', rev: 1500000000, cost: 1100000000 },
    { i: 0, ym: '2026-02', rev: 1800000000, cost: 1300000000 },
    { i: 0, ym: '2026-03', rev: 2000000000, cost: 1500000000 },
    { i: 0, ym: '2026-04', rev: 2200000000, cost: 1700000000 },
    { i: 1, ym: '2026-03', rev: 1200000000, cost: 950000000 },
    { i: 1, ym: '2026-04', rev: 1500000000, cost: 1150000000 },
    { i: 2, ym: '2026-02', rev: 800000000, cost: 620000000 },
    { i: 2, ym: '2026-03', rev: 1000000000, cost: 780000000 },
    { i: 2, ym: '2026-04', rev: 1100000000, cost: 850000000 }
  ];
  monthlySeeds.forEach((s) => {
    MonthlyService.create({
      projectId: created[s.i].id,
      yearMonth: s.ym,
      revenue: s.rev,
      cost: s.cost
    });
  });

  // 추정 샘플
  ForecastService.upsert({
    projectId: created[0].id,
    estimatedRevenue: 22000000000,
    estimatedCost: 16500000000
  });
  ForecastService.upsert({
    projectId: created[1].id,
    estimatedRevenue: 14500000000,
    estimatedCost: 11200000000
  });
  ForecastService.upsert({
    projectId: created[2].id,
    estimatedRevenue: 12500000000,
    estimatedCost: 9700000000
  });

  return { ok: true, count: created.length };
}

// ============================================================
// API 라우터
// ============================================================
const api = {
  // 대시보드
  'dashboard.summary': (params) => AnalyticsService.getDashboardSummary(params.yearMonth),
  'dashboard.trend': (params) => AnalyticsService.getMonthlyTrend(params.year),
  'dashboard.comparison': (params) => AnalyticsService.getProjectComparison(params.yearMonth),

  // 프로젝트
  'project.list': () => ProjectService.list(),
  'project.get': (params) => ProjectService.get(params.id),
  'project.create': (params) => ProjectService.create(params),
  'project.update': (params) => ProjectService.update(params.id, params),
  'project.remove': (params) => ProjectService.remove(params.id),
  'project.analysis': (params) => AnalyticsService.getProjectAnalysis(params.projectId, params.yearMonth),

  // 월별
  'monthly.listByProject': (params) => MonthlyService.listByProject(params.projectId),
  'monthly.listAll': () => MonthlyService.listAll(),
  'monthly.listByYear': (params) => MonthlyService.listByYear(params.year),
  'monthly.create': (params) => MonthlyService.create(params),
  'monthly.update': (params) => MonthlyService.update(params.id, params),
  'monthly.remove': (params) => MonthlyService.remove(params.id),
  'monthly.bulkUpsert': (params) => MonthlyService.bulkUpsert(params.items),

  // 추정
  'forecast.getByProject': (params) => ForecastService.getByProject(params.projectId),
  'forecast.upsert': (params) => ForecastService.upsert(params),

  // 시스템
  'system.seedSample': () => seedSampleData(),
  'system.resetAll': () => {
    DB = JSON.parse(JSON.stringify(DEFAULT_DB));
    commit();
    return { ok: true };
  },
  'system.user': () => ({ email: 'local@user', name: '로컬 사용자', role: 'admin' })
};

// ============================================================
// HTTP 서버
// ============================================================
function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', (chunk) => (body += chunk));
    req.on('end', () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch (err) {
        reject(new Error('잘못된 JSON: ' + err.message));
      }
    });
    req.on('error', reject);
  });
}

function sendJSON(res, status, payload) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type'
  });
  res.end(JSON.stringify(payload));
}

const server = http.createServer(async (req, res) => {
  // CORS preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    });
    res.end();
    return;
  }

  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname;

  // 정적 파일: index.html
  if (pathname === '/' || pathname === '/index.html') {
    if (!fs.existsSync(INDEX_FILE)) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('index.html을 찾을 수 없습니다. code.gs와 같은 폴더에 두세요.');
      return;
    }
    const html = fs.readFileSync(INDEX_FILE, 'utf8');
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(html);
    return;
  }

  // API
  if (pathname.startsWith('/api/')) {
    const action = pathname.replace('/api/', '');
    const handler = api[action];
    if (!handler) {
      sendJSON(res, 404, { ok: false, error: `알 수 없는 API: ${action}` });
      return;
    }
    try {
      let params = parsedUrl.query;
      if (req.method === 'POST') {
        params = await readBody(req);
      }
      const result = handler(params);
      sendJSON(res, 200, { ok: true, data: result });
    } catch (err) {
      console.error(`[API ERROR] ${action}:`, err.message);
      sendJSON(res, 400, { ok: false, error: err.message });
    }
    return;
  }

  // 404
  res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end('Not Found');
});

server.listen(PORT, () => {
  console.log('=========================================================');
  console.log('  현장별 매출·손익 관리 시스템 - 로컬 서버 시작');
  console.log('=========================================================');
  console.log(`  📂 데이터 파일: ${DB_FILE}`);
  console.log(`  🌐 접속 주소:   http://localhost:${PORT}`);
  console.log(`  📊 현장 수:     ${DB.projects.length}개`);
  console.log(`  📈 월별 기록:   ${DB.monthly.length}건`);
  console.log('=========================================================');
  console.log('  종료하려면 Ctrl+C');
  console.log('');
});

// 정상 종료 처리
process.on('SIGINT', () => {
  console.log('\n서버를 종료합니다...');
  commit();
  process.exit(0);
});
